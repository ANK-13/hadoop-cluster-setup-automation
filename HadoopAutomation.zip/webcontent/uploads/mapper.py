#!/usr/bin/python2

import sys

for i in sys.stdin:
	print i,

