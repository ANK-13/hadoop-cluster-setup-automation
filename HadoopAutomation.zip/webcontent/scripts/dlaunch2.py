#!/usr/bin/python2
import cgi,cgitb
import commands

print "Content-Type: text/html; charset=UTF-8 \n"

idx=cgi.FieldStorage()

img = idx.getvalue('img')
num = idx.getvalue('num')
"""
hip=idx.getvalue('hostip')
hpwd=idx.getvalue('hostpwd')
"""
"""
def ipcheck(ip):
	tmp=ip.split(".")
	for i in tmp:
		if int(i)>=0 and int(i)<256:
			flg=1
		else:
			flg=0
			break
	if flg==1:
		return True
	else:
		return False

if !ipcheck(hip):
	print "Ip  is incorrect"
"""

op=commands.getoutput("sudo docker ps -a").split("\n")
for i in op:
	usednames=i.split()
	print usednames[-1]+"\n"

print "<br> <b>Please avoid these names.</b>"

print """
<br><form action='dlaunch3.py' method="GET">
	"""
for j in range(int(num)):
	print "<br><br>Container{0} name:<input name=c{0} value=C{0}>".format(j)
print """
<input type="hidden" name=num value={0}>
<input type="hidden" name=img value={1}>
<br>
<input type="Submit">
</form>
""".format(num,img)
