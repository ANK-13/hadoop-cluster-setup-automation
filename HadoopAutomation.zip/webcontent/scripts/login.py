#!/usr/bin/python2

import cgi

print "Content-Type: text/html; charset=UTF-8 \n"
'''
print cgi.FieldStorage()
idx=cgi.FieldStorage()
usr=idx.getvalue('usrnm')
pwd=idx.getvalue('pass')

#info=cgi.FieldStorage()

#unm=info.getvalue('usrnm')
#pwd=info.getvalue('pass')

'''
usr=cgi.FormContent()['usrnm'][0]
pwd=cgi.FormContent()['pass'][0]
print "{0}    ->     {1}".format(usr,pwd)