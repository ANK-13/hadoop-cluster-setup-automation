#!/usr/bin/python2

import cgi
import commands

print "Content-Type: text/html; charset=UTF-8 \n"


packageName=cgi.FormContent()['rpm'][0]

print "Content in package name "+packageName

status=commands.getstatusoutput("sudo yum install {} -y".format(packageName))

if status[0]==0:
	print "Software Installed"
else:
	print "Software installation failed" 

