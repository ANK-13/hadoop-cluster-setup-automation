#!/usr/bin/python2

import cgi,cgitb
import commands

print "Content-Type: text/html; charset=UTF-8;"

print ""


ansi_status=commands.getstatusoutput("sudo ansible-playbook /webcontent/ansible/setup.yml -i /webcontent/ansible/hosts")
print ansi_status

nnformatstate=commands.getstatusoutput("sudo echo Y | sshpass -p {0} ssh -o stricthostkeychecking=no {1} hadoop namenode -format".format("docker","172.17.0.2"))

print nnformatstate
