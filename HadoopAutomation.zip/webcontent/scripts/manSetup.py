#!/usr/bin/python2

import cgi,cgitb
import commands

print "Content-Type: text/html; charset=UTF-8;"
print ""

f=open("../ansible/hosts","r")
hosts=f.readlines()
f.close()

print "<form action='manSetup2.py' method='POST'>"
print "Select name node: <select name='nnip'>"

z=0
for host in hosts:
	if z==0:
		z+=1
	else:
		hostip=host.split()
		print "<option value="+hostip[0]+">"+hostip[0]+"</option>"

print "</select>"

print "<br />namenode port number: <input type='number' name='nnport' min=1025 max=49151>"

print "<br /><br />Select Job Tracker: <select name='jtip'>"

z=0
for host in hosts:
	if z==0:
		z+=1
	else:
		hostip=host.split()
		print "<option>"+hostip[0]+"</option>"

print "</select>"
print "<br />jt  port number: <input type='number' name='jtport' min=1025 max=49151>"
print "<input type='submit'>"
print "</form>"
