#!/usr/bin/python2

import cgi,cgitb
import commands

print "Content-Type: text/html; charset=UTF-8 \n"



idx=cgi.FieldStorage()

num = int(idx.getvalue('num'))
img=idx.getvalue('img')

print "India"
f=open("../ansible/hosts","w")

f.write("[docker]\n")


print "file created"
for i in range(num):
	name=idx.getvalue('c{}'.format(i))
	print name
	print img
	lauchstate=commands.getstatusoutput("sudo docker run -dit --name {0} --privileged=true {1}".format(name,img))
	print lauchstate
	if lauchstate[0]==0:
		ip=commands.getoutput("sudo docker inspect {0} | jq '.[].NetworkSettings.Networks.bridge.IPAddress'".format(name))
		print "container name {0} : {1}".format(name,ip)
		f.write("{0} ansible_ssh_user=root ansible_ssh_pass=docker\n".format(ip.strip("\"")))
f.close()
print "host file created"
