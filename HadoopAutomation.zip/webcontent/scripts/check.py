#!/usr/bin/python2

print "Content-Type: text/html; charset=UTF-8;"
print ""


f = open("../ansible/hosts","r")
lines=f.readlines()
for line in lines:
	tmp=line.split()
	if tmp[0]=="[namenode]":
		break
	elif tmp[0]=="[docker]":
		pass
	else:
		dnip=tmp[0]
		dnpass=tmp[2].split("=")
		print dnip
		print dnpass[1]

"""
		dnstate=commands.getstatusoutput("sudo sshpass -p {1} ssh -o stricthostkeychecking=no {0} hadoop.sh start datanode".format(dnip,dnpass[1]))
		ttstate=commands.getstatusoutput("sudo sshpass -p {1} ssh -o stricthostkeychecking=no {0} hadoop.sh start tasktracker".format(dnip,dnpass[1]))
"""
