#!/usr/bin/python2

import cgi,cgitb
import commands

print "Content-Type: text/html; charset=UTF-8;"

print ""

print "I m here"
try:
	f = open("../ansible/hosts","r")
except Exception:
	print "Sorry, please contact administratior. hosts file is missing"
else:
	f.seek(0,0)
	lines=f.readlines()
	print "<br />"
	print "Setting up things in {0} containers".format(len(lines)-1)
	f.close()

	f = open("../ansible/hosts","w")
	
	cnt=0
	for line in lines:
		if cnt==1:
			nnline=line
		elif cnt==2:
			jtline=line
		else:
			f.write(line)
		cnt+=1
	
	f.write("[namenode]\n")
	f.write(nnline)

	f.write("[jobtracker]\n")
	f.write(jtline)
	f.close()
	
	print "Auto hosts setup is ready"
	
	tmp=lines[1].split()
	nnip=tmp[0]
	tmp=lines[2].split()
	jtip=tmp[0]

# Making file for core site
	
	coresite="""<?xml version="1.0"?>
<?xml-stylesheet type="text/xsl" href="configuration.xsl"?>

<!-- Put site-specific property overrides in this file. -->

<configuration>
<property>
<name>fs.default.name</name>
<value>hdfs://{0}:{1}</value>
</property>
</configuration>""".format(nnip,"10001")
	
	f = open("../ansible/nn/core-site.xml","w")
	f.write(coresite)
	f.close()

	hdfssite="""<?xml version='1.0'?>
<?xml-stylesheet type='text/xsl' href='configuration.xsl'?>
	
<!-- Put site-specific property overrides in this file. -->

<configuration>
<property>
<name>dfs.name.dir</name>
<value>/master</value>
</property>
</configuration>"""

	f = open("../ansible/nn/hdfs-site.xml","w")
	f.write(hdfssite)
	f.close()
	
	

# making file for JT


	mapredsite="""<?xml version="1.0"?>
<?xml-stylesheet type="text/xsl" href="configuration.xsl"?>

<!-- Put site-specific property overrides in this file. -->
<configuration>
<property>
<name>mapred.job.tracker</name>
<value>{0}:9001</value>
</property>
</configuration>
""".format(jtip)

	f = open("../ansible/jt/mapred-site.xml","w")
	f.write(mapredsite)
	f.close()

	f = open("../ansible/jt/core-site.xml","w")
	f.write(coresite)
	f.close()

#making files for Datanodes and task trackers
	
	f = open("../ansible/dn_tt/core-site.xml","w")
	f.write(coresite)
	f.close()

	hdfssite="""<?xml version='1.0'?>
<?xml-stylesheet type='text/xsl' href='configuration.xsl'?>
	
<!-- Put site-specific property overrides in this file. -->

<configuration>
<property>
<name>dfs.data.dir</name>
<value>/datanode</value>
</property>
</configuration>"""

	f = open("../ansible/dn_tt/hdfs-site.xml","w")
	f.write(hdfssite)
	f.close()

	f = open("../ansible/dn_tt/mapred-site.xml","w")
	f.write(mapredsite)
	f.close()

	print "Setup files sre ready to copy"
	
	ansi_status=commands.getstatusoutput("sudo ansible-playbook /webcontent/ansible/setup.yml -i /webcontent/ansible/hosts")
	print ansi_status
	ansi_status=commands.getstatusoutput("sudo ansible-playbook /webcontent/ansible/setup1.yml -i /webcontent/ansible/hosts")
	print ansi_status
	ansi_status=commands.getstatusoutput("sudo ansible-playbook /webcontent/ansible/setup3.yml -i /webcontent/ansible/hosts")
	print ansi_status
	print "<a href='manSetup3.py'>Click here to Start Namenode Service</a>"

	print """
	<input type='hidden' name='nnip' value={0}>
	<input type='hidden' name='nnpass' value={1}>
	<input type='hidden' name='jtip' value={2}>
	<input type='hidden' name='jtpass' value={3}>
	""".format(nnip,nnpass[1],jtip,jtpass[1])

#	ansi_status=commands.getstatusoutput("ansible-playbook /ansible/setup.yml /ansible")
