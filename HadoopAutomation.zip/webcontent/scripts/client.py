#!/usr/bin/python2

import cgi,cgitb
import commands

print "Content-Type: text/html; charset=UTF-8;"

x=cgi.FieldStorage()
if x.getvalue('unm')=='admin' and x.getvalue('pwd')=='admin':
	print ""
	print "Location: ../scripts/client_launch.py"
else:
	print "Location: ../proj/client.html"
	print ""




