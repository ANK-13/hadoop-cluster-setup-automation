#!/usr/bin/python2
import cgi,cgitb
import commands

print "Content-Type: text/html; charset=UTF-8 \n"

x=cgi.FieldStorage()
hostip=x.getvalue('hostip')
hostpwd=x.getvalue('hostpwd')

a=commands.getstatusoutput("sudo sshpass -p {0} ssh -o stricthostkeychecking=no {1} date".format(hostpwd,hostip))

if a[0]==0:
	f = open('../ansible/hostpc','w')
	f.write(hostip+":"+hostpwd)
	f.close()
else:
	print "Unable to connect to host"


