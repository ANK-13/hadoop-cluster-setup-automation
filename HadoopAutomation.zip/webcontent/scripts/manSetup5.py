#!/usr/bin/python2

import cgi,cgitb
import commands

print "Content-Type: text/html; charset=UTF-8;"

print ""

x=cgi.FieldStorage()

nnip=x.getvalue('nnip')
nnpass=x.getvalue('nnpass')
jtip=x.getvalue('jtip')
jtpass=x.getvalue('jtpass')


f = open("../ansible/hosts","r")
lines=f.readlines()
for line in lines:
	tmp=line.split()
	if tmp[0]=="[namenode]":
		break
	elif tmp[0]=="[docker]":
		pass
	else:
		dnip=tmp[0]
		dnpass=tmp[2].split("=")
		nnformatstate=commands.getstatusoutput("sudo sshpass -p {0} ssh -o stricthostkeychecking=no {1} datanode.sh".format(dnpass[1],dnip))
		print nnformatstate
print "<a href={0}:50070'>Click here to show services</a>".format(nnip)


