#!/usr/bin/python2

import cgi,cgitb
import commands

print "Content-Type: text/html; charset=UTF-8;"

print ""

nnformatstate=commands.getstatusoutput("sudo sshpass -p {0} ssh -o stricthostkeychecking=no {1} ".format('docker','172.17.0.2'))
"""
f = open('../ansible/hostpc','r')
f.seek(0)
op=f.readline().split(':')
"""
#nnformatstate=commands.getstatusoutput("sudo sshpass -p {0} ssh -o stricthostkeychecking=no {1} docker exec C0 echo Y |hadoop namenode -format".format(op[1],op[0]))

#nnformatstate=commands.getstatusoutput("docker exec {0} hadoop namenode -format".format('C0'))

print nnformatstate
