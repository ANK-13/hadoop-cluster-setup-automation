#!/usr/bin/python2

import cgi,cgitb
import commands

print "Content-Type: text/html; charset=UTF-8;"

mode=cgi.FieldStorage().getvalue("mode")

if mode=="auto":
	print "Location: autoSetup.py"
	print ""
else:
	print "Location: manSetup.py"
	print ""
