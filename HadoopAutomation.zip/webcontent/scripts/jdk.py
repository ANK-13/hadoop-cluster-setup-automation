#!/usr/bin/python
import cgi

print "Content-Type: text/html; charset=UTF-8 \n"

print "Location: /index.html"

print "<script>window.location.href = '/index.html'</script>"