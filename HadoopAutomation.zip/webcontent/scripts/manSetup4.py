#!/usr/bin/python2

import cgi,cgitb
import commands

print "Content-Type: text/html; charset=UTF-8;"

print ""

x=cgi.FieldStorage()

nnip=x.getvalue('nnip')
nnpass=x.getvalue('nnpass')
jtip=x.getvalue('jtip')
jtpass=x.getvalue('jtpass')

nnformatstate=commands.getstatusoutput("sudo sshpass -p {0} ssh -o stricthostkeychecking=no {1} jobtracker.sh".format(jtpass,jtip))
print nnformatstate

print """
	<form action='manSetup5.py' method='POST'>
	<input type='hidden' name='nnip' value={0}>
	<input type='hidden' name='nnpass' value={1}>
	<input type='hidden' name='jtip' value={2}>
	<input type='hidden' name='jtpass' value={3}>
	<input type='submit' value='Start Datanode Service'>
	</form>
	""".format(nnip,nnpass[1],jtip,jtpass[1])
print "<a href='manSetup5.py'>Click here to Start Datanode and Tasktracker Service</a>"


