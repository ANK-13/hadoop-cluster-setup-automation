#!/usr/bin/python2

import cgi,cgitb,sys
import commands

print "Content-Type: text/html; charset=UTF-8;"

print ""

x=cgi.FieldStorage()

lauchstate=commands.getstatusoutput("sudo docker run -dit --name {0} --privileged=true centos_proj:v1".format(x.getvalue('nm')))

if lauchstate[0]==0:
		ip=commands.getoutput("sudo docker inspect {0} | jq '.[].NetworkSettings.Networks.bridge.IPAddress'".format(x.getvalue('nm')))
		print "container name {0} : {1}".format(name,ip)
else:
	print "Error: {}".format(lauchstate[1])
f.close()


