#!/usr/bin/python2

import cgi,cgitb
import commands

print "Content-Type: text/html; charset=UTF-8;"

print ""

ips=cgi.FieldStorage()
nnip=ips.getvalue('nnip')
jtip=ips.getvalue('jtip')
nnport=ips.getvalue('nnport')
jtport=ips.getvalue('jtport')



try:
	f = open("../ansible/hosts","r")
except Exception:
	print "Sorry, please contact administratior. hosts file is missing"
else:
	f.seek(0,0)
	lines=f.readlines()
	print "<br />"
	print "Setting up things in {0} containers<br />".format(len(lines)-1)
	f.close()

	f = open("../ansible/hosts","w")
	
	try:
		for line in lines:
			tmp=line.split()
			if tmp[0]==nnip:
				nnline=line
			elif tmp[0]==jtip:
				jtline=line
			else:
				f.write(line)
	except Exception:
		print "Please recheck ur ips or hosts file"
	
	f.write("[namenode]\n")
	f.write(nnline)

	f.write("[jobtracker]\n")
	f.write(jtline)

	f.close()
	
	print "<br />manual hosts file is ready"
	

# Making file for core site
	
	coresite="""<?xml version="1.0"?>
<?xml-stylesheet type="text/xsl" href="configuration.xsl"?>

<!-- Put site-specific property overrides in this file. -->

<configuration>
<property>
<name>fs.default.name</name>
<value>hdfs://{0}:{1}</value>
</property>
</configuration>""".format(nnip,nnport)
	f = open("../ansible/nn/core-site.xml","w")
	f.write(coresite)
	f.close()


	hdfssite="""<?xml version='1.0'?>
<?xml-stylesheet type='text/xsl' href='configuration.xsl'?>
	
<!-- Put site-specific property overrides in this file. -->

<configuration>
<property>
<name>dfs.name.dir</name>
<value>/master</value>
</property>
</configuration>"""
#	print "---------->"
	f = open("../ansible/nn/hdfs-site.xml","w")
#	print "==========>>>>"
	f.write(hdfssite)
#	print "==========>>>>"
	f.close()
#	print "==========>>>>"
	
	print "<br> made file for coresite"
	mapredsite="""<?xml version="1.0"?>
<?xml-stylesheet type="text/xsl" href="configuration.xsl"?>

<!-- Put site-specific property overrides in this file. -->
<configuration>
<property>
<name>mapred.job.tracker</name>
<value>{0}:{1}</value>
</property>
</configuration>
""".format(jtip,jtport)

	f = open("../ansible/jt/mapred-site.xml","w")
	f.write(mapredsite)
	f.close()

	f = open("../ansible/jt/core-site.xml","w")
	f.write(coresite)
	f.close()
	print "<br> making file for JT"
#making files for Datanodes and task trackers
	
	f = open("../ansible/dn_tt/core-site.xml","w")
	f.write(coresite)
	f.close()

	hdfssite="""<?xml version='1.0'?>
<?xml-stylesheet type='text/xsl' href='configuration.xsl'?>
	
<!-- Put site-specific property overrides in this file. -->

<configuration>
<property>
<name>dfs.data.dir</name>
<value>/datanode</value>
</property>
</configuration>"""

	f = open("../ansible/dn_tt/hdfs-site.xml","w")
	f.write(hdfssite)
	f.close()

	f = open("../ansible/dn_tt/mapred-site.xml","w")
	f.write(mapredsite)
	f.close()
	print "<br> making file for JT"
	print "Setup files are ready to copy"

	nnlist=nnline.split()
	nnpass=nnlist[2].split("=")

	jtlist=jtline.split()
	jtpass=jtlist[2].split("=")

	ansi_status=commands.getstatusoutput("sudo ansible-playbook /webcontent/ansible/setup.yml -i /webcontent/ansible/hosts")
	print ansi_status
	ansi_status=commands.getstatusoutput("sudo ansible-playbook /webcontent/ansible/setup1.yml -i /webcontent/ansible/hosts")
	print ansi_status
	ansi_status=commands.getstatusoutput("sudo ansible-playbook /webcontent/ansible/setup3.yml -i /webcontent/ansible/hosts")
	print ansi_status

	print """
	<form action='manSetup3.py' method='POST'>
	<input type='hidden' name='nnip' value={0}>
	<input type='hidden' name='nnpass' value={1}>
	<input type='hidden' name='jtip' value={2}>
	<input type='hidden' name='jtpass' value={3}>
	<input type='submit' value='Start Namenode Service'>
	</form>
	""".format(nnip,nnpass[1],jtip,jtpass[1])
	#nnformatstate=commands.getstatusoutput("sudo sshpass -p {0} ssh -o stricthostkeychecking=no {1} namenode.sh".format(nnpass[1],nnip))
	#print nnformatstate
"""
	ansi_status=commands.getstatusoutput("sudo ansible-playbook /webcontent/ansible/setup.yml -i /webcontent/ansible/hosts")
	print ansi_status
	nnformatstate=commands.getstatusoutput("sudo echo Y | sshpass -p {0} ssh -o stricthostkeychecking=no {1} hadoop namenode -format".format(nnpass[1],nnip))
	nnstate=commands.getstatusoutput("sudo sshpass -p {0} ssh -o stricthostkeychecking=no {1} hadoop-daemon.sh start namenode".format(nnpass[1],nnip))

	jtstate=commands.getstatusoutput("sudo sshpass -p {1} ssh -o stricthostkeychecking=no {0} hadoop.sh start jobtracker".format(jtip,jtpass[1]))

	for line in lines:
		tmp=line.split()
		if tmp[0]=="[namenode]":
			break
		elif tmp[0]=="[docker]":
			pass
		else:
			dnip=tmp[0]
			dnpass=tmp[2].split("=")
			dnstate=commands.getstatusoutput("sudo sshpass -p {1} ssh -o stricthostkeychecking=no {0} hadoop.sh start datanode".format(dnip,dnpass[1]))
			ttstate=commands.getstatusoutput("sudo sshpass -p {1} ssh -o stricthostkeychecking=no {0} hadoop.sh start tasktracker".format(dnip,dnpass[1]))

"""
