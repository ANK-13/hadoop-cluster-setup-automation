#!/usr/bin/python2
import cgi,cgitb
import commands

print "Content-Type: text/html; charset=UTF-8 \n"

idx=cgi.FieldStorage()

ip=idx.getvalue('ip')
pwd=idx.getvalue('pass')

print ip
print "\n"
print pwd

#JDK iNSTALTION

if idx.getvalue('setup')=='jdk':
	jdkcheck=commands.getstatusoutput("sshpass -p {1} ssh -o stricthostkeychecking=no -l root {0} -y rpm -q jdk".format(ip,pwd))
	if jdkcheck[0]==0:
		print "JDK is already installed version -> {0}".format(jdkcheck[1])
	else:
		cpJDK=commands.getstatusoutput("sshpass -p {0} scp -o strictkeyhostkeychecking=no /soft/jdk-7u79-linux-x64.rpm {1}@/".format(pwd,ip))
		print cpJDK
		jdkinstl=commands.getstatusoutput("sshpass -p {1} ssh -o stricthostkeychecking=no -l root {0} -y rpm -ivh /jdk-7u79-linux-x64.rpm ".format(ip,pwd))
		if jdkinstl[0]==0:
			print "JDL 1.7 was installed Successfully in ur system"
			print "<a href='/index.html'>Click Here to go to hamepage</a>"
		else:
			print "JDL 1.7 installation was failed"
			print "<a href='/index.html'>Click Here to go to hamepage</a>"


elif idx.getvalue('setup')=='hdp':
	hdpcheck=commands.getstatusoutput("sshpass -p {1} ssh -o stricthostkeychecking=no -l root {0} -y rpm -q hadoop".format(ip,pwd))
	if hdpcheck[0]==0:
		print "Hadoop is already installed version -> {0}".format(hdpcheck[1])
	else:
		cpHadoop=commands.getstatusoutput("sshpass -p {0} scp -o strictkeyhostkeychecking=no /soft/hadoop-1.2.1-1.x86_64.rpm {1}@/".format(pwd,ip))
		print cpHadoop
		hdpinstl=commands.getstatusoutput("sshpass -p {1} ssh -o stricthostkeychecking=no -l root {0} -y rpm -ivh /hadoop-1.2.1-1.x86_64.rpm ".format(ip,pwd))
		if hdpinstl[0]==0:
			print "hadoop was installed Successfully in ur system"
			print "<a href='/index.html'>Click Here to go to hamepage</a>"
		else:
			print "Hadoop installation was failed"
			print "<a href='/index.html'>Click Here to go to hamepage</a>"
	

elif idx.getvalue('setup')=='nnd':
	hdpcheck=commands.getstatusoutput("sshpass -p {1} ssh -o stricthostkeychecking=no -l root {0} -y rpm -q hadoop".format(ip,pwd))
	if hdfcheck[0]!=0:
		print "Hadoop is not installed first install hadoop.Please Install it from link Below"
		print "<a href='/index.html'>Click Here</a>"
	else:
		print """
			Please enter port number
		"""
		print "Setting IP of current server as MAsters IP...."

#print idx.getvalue('setup')+"       "+idx.getvalue("ip")
"""
