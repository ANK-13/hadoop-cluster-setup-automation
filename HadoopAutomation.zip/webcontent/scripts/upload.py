#!/usr/bin/python2


import cgi,cgitb
cgitb.enable()
import commands

print "content-type:  text/html"
print ""

fdata=cgi.FieldStorage()

fnm=fdata['fname'].filename

lines=fdata['fname'].file.readlines()



fh=open('../uploads/{0}'.format(fnm) , 'w')

for line in lines:
	fh.write(line)
fh.close()


cstatus=commands.getstatusoutput("sudo  hadoop  fs  -put  ../uploads/{0}   /".format(fnm))

print cstatus





