#!/usr/bin/python2
import cgi,cgitb
import commands

print "Content-Type: text/html; charset=UTF-8 \n"

"""
idx=cgi.FieldStorage()
hip=idx.getvalue('hostip')
hpwd=idx.getvalue('hostpwd')
"""
z=1

print "<form action='dlaunch2.py' action='POST'>"
print "Select the required image:<select name='img'>"

for i in commands.getoutput("sudo docker images").split("\n"):
	if z==1:
		print i+"<br />"
		z+=1
		pass
	else:
		print i+"<br />"
		j=i.split()
		print "<option value="+j[0]+":"+j[1]+">"+j[0]+":"+j[1]+"</option>"


print """
</select>
<br />
Enter number of containers<input type=number name='num' min=3><br />
<input type=submit>
</form>
"""
"""
idx=cgi.FieldStorage()

os = idx.getvalue('os')
num = idx.getvalue('number')

ip=idx.getvalue('ip')
pwd=idx.getvalue('pwd')

idx=commands
s"""
