#!/usr/bin/python2
import cgi,cgitb
import commands

print "Content-Type: text/html; charset=UTF-8 \n"

ansi_status=commands.getstatusoutput("sudo echo Y | ansible-playbook /webcontent/ansible/namenode.yml -i /webcontent/ansible/hosts")

print ansi_status
