#!/usr/bin/python2

import cgi,cgitb
import commands

print "Content-Type: text/html; charset=UTF-8;"

print ""

f=open('../ansible/hostpc','r')
a=f.readline().split(":")

op=commands.getstatusoutput("sshpass -p {0} ssh -o stricthostkeychecking=no {1} cp ../ansible/jt/core-site.xml /etc/hadoop/core-site.xml".format(a[1],a[0]))
print op

op=commands.getstatusoutput("sshpass -p {0} ssh -o stricthostkeychecking=no {1} cp ../ansible/jt/mapred-site.xml /etc/hadoop/mapred-site.xml".format(a[1],a[0]))
print op

print """
<form enctype='multipart/form-data' action='../scripts/upload.py' method='POST'>
<input type=file name='fname'><br />
<input type=submit>
</form>
"""

print """
<br>
<br>
"""
cstatus=commands.getstatusoutput("sudo  hadoop  fs -ls /")

print cstatus[1]


