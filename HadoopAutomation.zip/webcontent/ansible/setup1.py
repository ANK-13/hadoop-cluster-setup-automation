- hosts: jobtracker
  tasks:
    - name: Copying core site
      copy:
        src: "/webcontent/ansible/jt/core-site.xml"
        dest: "/etc/hadoop/core-site.xml"

    - name: Creating mapred site       
      copy:
        src: "/webcontent/ansible/jt/hdfs-site.xml"
        dest: "/etc/hadoop/mapred-site.xml"

